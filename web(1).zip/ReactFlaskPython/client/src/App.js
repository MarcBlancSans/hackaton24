import React, {useState, useEffect} from 'react'
import { apiBaseUrl } from './constatn';

function App() {

  const [data, setData] = useState([{}]);

  useEffect(() => {
    fetch(`${apiBaseUrl}/members`).then(
      res => res.json()
    ).then(
      data => {
        setData(data)
        console.log(data)
      }
    )
  }, [])

  return (
    <div>App</div>
  )
}

export default App